# Core Business Rules

- **Product Type**: The store exclusively sells **Ready-to-Stitch Fabric** (unstitched/semi-stitched materials), NOT fully stitched or ready-to-wear garments.
- **Messaging**: Always ensure product pages, descriptions, and UI elements clearly communicate that the items are "Ready-to-Stitch" and stitching is not included.
- **Size Selection**: While sizes are selected, this is to ensure the correct amount of fabric or pre-cut panels are provided for the customer's tailor.
