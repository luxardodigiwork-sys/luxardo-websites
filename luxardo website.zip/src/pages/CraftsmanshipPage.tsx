import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { ArrowRight, X } from 'lucide-react';

export default function CraftsmanshipPage() {
  const { scrollY } = useScroll();
  
  // Hero Parallax
  const heroY1 = useTransform(scrollY, [0, 1000], [0, 200]);
  const heroY2 = useTransform(scrollY, [0, 1000], [0, 100]);
  const heroY3 = useTransform(scrollY, [0, 1000], [0, 50]);
  const heroOpacity = useTransform(scrollY, [0, 600], [1, 0]);

  // Product Experience Modal
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  const processSteps = [
    {
      title: "Fabric Selection",
      desc: "Sourcing only the finest raw materials from heritage mills.",
      img: "https://images.unsplash.com/photo-1584916201218-f4242ceb4809?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Structural Design",
      desc: "Architecting the silhouette for presence and posture.",
      img: "https://images.unsplash.com/photo-1558655146-d09347e92766?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Pattern Engineering",
      desc: "Mathematical precision applied to human form.",
      img: "https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Precision Crafting",
      desc: "Hand-stitched details where machines fall short.",
      img: "https://images.unsplash.com/photo-1598532163257-ae3c6b2524b6?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Final Presentation",
      desc: "Rigorous inspection before the Luxardo seal is applied.",
      img: "https://images.unsplash.com/photo-1594938298596-03ef667d4dc1?q=80&w=1000&auto=format&fit=crop"
    }
  ];

  const productViews = [
    { label: "Front", img: "https://images.unsplash.com/photo-1594938298596-03ef667d4dc1?q=80&w=1000&auto=format&fit=crop" },
    { label: "Back", img: "https://images.unsplash.com/photo-1593030761757-71fae45fa0e7?q=80&w=1000&auto=format&fit=crop" },
    { label: "Detail", img: "https://images.unsplash.com/photo-1584916201218-f4242ceb4809?q=80&w=1000&auto=format&fit=crop" }
  ];

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-brand-black selection:bg-brand-black selection:text-brand-white">
      
      {/* SECTION 1 — HERO */}
      <section className="relative h-[80vh] md:h-screen w-full overflow-hidden bg-brand-black flex items-center justify-center">
        {/* Layered Parallax Backgrounds */}
        <motion.div style={{ y: heroY1, opacity: heroOpacity }} className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=2000&auto=format&fit=crop" alt="Fabric" className="w-full h-full object-cover opacity-40" referrerPolicy="no-referrer" />
        </motion.div>
        <motion.div style={{ y: heroY2, opacity: heroOpacity }} className="absolute inset-0 z-10 mix-blend-overlay">
          <img src="https://images.unsplash.com/photo-1598532163257-ae3c6b2524b6?q=80&w=2000&auto=format&fit=crop" alt="Hands" className="w-full h-full object-cover opacity-30 grayscale" referrerPolicy="no-referrer" />
        </motion.div>
        <motion.div style={{ y: heroY3, opacity: heroOpacity }} className="absolute inset-0 z-20 mix-blend-screen">
          <img src="https://images.unsplash.com/photo-1594938298596-03ef667d4dc1?q=80&w=2000&auto=format&fit=crop" alt="Garment" className="w-full h-full object-cover opacity-20" referrerPolicy="no-referrer" />
        </motion.div>
        
        <div className="absolute inset-0 bg-gradient-to-b from-brand-black/30 via-transparent to-brand-black z-30" />

        <div className="relative z-40 text-center px-6 max-w-5xl mx-auto flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <h1 className="text-5xl md:text-8xl lg:text-[120px] font-display text-brand-white tracking-tight leading-[1] mb-4 md:mb-6">
              Crafted with Discipline
            </h1>
            <h2 className="text-3xl md:text-6xl lg:text-[80px] font-display text-brand-white/80 tracking-tight leading-[1] mb-8 md:mb-12 italic font-light">
              Defined by Precision
            </h2>
            <p className="text-sm md:text-lg font-sans text-brand-white/60 tracking-widest uppercase font-bold max-w-2xl mx-auto">
              We do not design for volume. We construct for presence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* SECTION 2 — PROCESS FLOW */}
      <section className="py-24 md:py-40 px-6 md:px-12 max-w-[1800px] mx-auto">
        <div className="mb-16 md:mb-24 flex items-center gap-6">
          <span className="w-12 md:w-24 h-[1px] bg-brand-black"></span>
          <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-brand-black">The Process</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 md:gap-6">
          {processSteps.map((step, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: idx * 0.1, ease: "easeOut" }}
              className="group cursor-pointer"
            >
              <div className="aspect-[3/4] overflow-hidden mb-6 bg-brand-black/5 relative">
                <motion.img 
                  src={step.img} 
                  alt={step.title}
                  className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-brand-black/0 group-hover:bg-brand-black/10 transition-colors duration-500" />
              </div>
              <div className="space-y-3 transform transition-transform duration-500 group-hover:-translate-y-2">
                <div className="text-[9px] font-mono text-brand-black/40">0{idx + 1}</div>
                <h3 className="text-lg md:text-xl font-display tracking-tight text-brand-black">{step.title}</h3>
                <p className="text-xs md:text-sm font-sans text-brand-secondary/80 font-light leading-relaxed">
                  {step.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* SECTION 3 — DESIGN PHILOSOPHY */}
      <section className="py-32 md:py-48 bg-brand-white flex items-center justify-center px-6 text-center border-y border-brand-black/5">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="max-w-4xl"
        >
          <h2 className="text-4xl md:text-6xl lg:text-8xl font-display tracking-tight leading-[1.1] text-brand-black">
            Inspired by armory structure.<br />
            <span className="text-brand-black/40 italic font-light">Refined into modern aesthetic.</span>
          </h2>
        </motion.div>
      </section>

      {/* SECTION 4 — PRODUCT EXPERIENCE */}
      <section className="py-24 md:py-40 px-6 md:px-12 max-w-[1800px] mx-auto">
        <div className="mb-16 md:mb-24 flex items-center gap-6 justify-end">
          <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-brand-black">The Anatomy</span>
          <span className="w-12 md:w-24 h-[1px] bg-brand-black"></span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {productViews.map((view, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: idx * 0.2, ease: "easeOut" }}
              className="relative group perspective-[1000px]"
            >
              <div 
                className="aspect-[4/5] overflow-hidden bg-brand-black/5 cursor-zoom-in transition-transform duration-700 ease-out group-hover:rotate-y-2 group-hover:rotate-x-2 group-hover:shadow-2xl"
                onClick={() => setZoomedImage(view.img)}
              >
                <img 
                  src={view.img} 
                  alt={view.label}
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="mt-6 text-center">
                <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-brand-black/60">
                  {view.label} View
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* SECTION 5 — MATERIAL DETAIL */}
      <section className="relative h-[60vh] md:h-[80vh] w-full overflow-hidden bg-brand-black">
        <motion.div 
          initial={{ scale: 1.1 }}
          whileInView={{ scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 2, ease: "easeOut" }}
          className="absolute inset-0"
        >
          <img 
            src="https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=2000&auto=format&fit=crop" 
            alt="Material Detail" 
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-transparent to-transparent" />
        
        <div className="absolute bottom-0 left-0 w-full p-8 md:p-24">
          <div className="max-w-2xl">
            <h3 className="text-3xl md:text-5xl font-display text-brand-white mb-6">Uncompromising Texture</h3>
            <p className="text-sm md:text-base font-sans text-brand-white/70 font-light leading-relaxed">
              Every thread is chosen for its weight, drape, and resilience. We utilize fabrics that command attention and stand the test of time, ensuring the garment feels as substantial as it looks.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 6 — CTA */}
      <section className="py-32 md:py-48 bg-brand-white text-center px-6">
        <div className="max-w-2xl mx-auto space-y-12">
          <h2 className="text-4xl md:text-6xl font-display tracking-tight text-brand-black">
            Begin Your Journey
          </h2>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <Link 
              to="/collections" 
              className="group relative px-8 py-4 bg-brand-black text-brand-white overflow-hidden flex items-center justify-center"
            >
              <div className="absolute inset-0 bg-brand-secondary translate-y-[100%] group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
              <span className="relative flex items-center gap-4 text-[10px] uppercase tracking-[0.3em] font-bold">
                Explore Craft <ArrowRight size={14} className="transform group-hover:translate-x-1 transition-transform" />
              </span>
            </Link>
            <Link 
              to="/prime-membership" 
              className="px-8 py-4 border border-brand-black/20 hover:border-brand-black transition-colors duration-500 flex items-center justify-center"
            >
              <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-brand-black">
                Request Private Access
              </span>
            </Link>
          </div>
        </div>
      </section>

      {/* Zoom Modal */}
      <AnimatePresence>
        {zoomedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-brand-black/95 backdrop-blur-sm flex items-center justify-center p-4 md:p-12 cursor-zoom-out"
            onClick={() => setZoomedImage(null)}
          >
            <button 
              className="absolute top-6 right-6 text-brand-white/50 hover:text-brand-white transition-colors"
              onClick={() => setZoomedImage(null)}
            >
              <X size={32} strokeWidth={1} />
            </button>
            <motion.img 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              src={zoomedImage} 
              alt="Zoomed Detail" 
              className="max-w-full max-h-full object-contain shadow-2xl"
              referrerPolicy="no-referrer"
            />
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

