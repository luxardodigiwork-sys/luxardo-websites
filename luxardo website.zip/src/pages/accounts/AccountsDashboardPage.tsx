import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  RotateCcw, 
  CreditCard, 
  Banknote,
  Search,
  Filter,
  Download,
  Eye,
  CheckSquare,
  XCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { storage } from '../../utils/localStorage';
import { formatCurrency } from '../../utils/currency';
import { Order } from '../../types';

type FilterType = 'all' | 'paid' | 'confirmed' | 'pending' | 'refunded' | 'cod' | 'prepaid';
type DateRangeType = 'all' | 'today' | 'week' | 'month';

export default function AccountsDashboardPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [dateRange, setDateRange] = useState<DateRangeType>('all');

  useEffect(() => {
    setOrders(storage.getOrders());
  }, []);

  const stats = useMemo(() => {
    const totalRevenue = orders.filter(o => o.paymentStatus === 'paid' || o.paymentStatus === 'confirmed').reduce((sum, o) => sum + o.totalAmount, 0);
    const paidOrders = orders.filter(o => o.paymentStatus === 'paid' || o.paymentStatus === 'confirmed').length;
    const pendingPayments = orders.filter(o => o.paymentStatus === 'pending').length;
    const confirmedPayments = orders.filter(o => o.paymentStatus === 'confirmed').length;
    const refundedOrders = orders.filter(o => o.paymentStatus === 'refunded').length;
    const codOrders = orders.filter(o => o.paymentMethod === 'cod').length;
    const prepaidOrders = orders.filter(o => o.paymentMethod !== 'cod').length;

    return {
      totalRevenue,
      paidOrders,
      pendingPayments,
      confirmedPayments,
      refundedOrders,
      codOrders,
      prepaidOrders
    };
  }, [orders]);

  const filteredOrders = useMemo(() => {
    let result = [...orders];

    // Search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(o => 
        o.id.toLowerCase().includes(query) ||
        o.userName.toLowerCase().includes(query) ||
        o.userEmail.toLowerCase().includes(query)
      );
    }

    // Filter
    if (activeFilter !== 'all') {
      if (activeFilter === 'paid') result = result.filter(o => o.paymentStatus === 'paid' || o.paymentStatus === 'confirmed');
      if (activeFilter === 'confirmed') result = result.filter(o => o.paymentStatus === 'confirmed');
      if (activeFilter === 'pending') result = result.filter(o => o.paymentStatus === 'pending');
      if (activeFilter === 'refunded') result = result.filter(o => o.paymentStatus === 'refunded');
      if (activeFilter === 'cod') result = result.filter(o => o.paymentMethod === 'cod');
      if (activeFilter === 'prepaid') result = result.filter(o => o.paymentMethod !== 'cod');
    }

    // Date Range
    if (dateRange !== 'all') {
      const now = new Date();
      result = result.filter(o => {
        const orderDate = new Date(o.createdAt);
        if (dateRange === 'today') return orderDate.toDateString() === now.toDateString();
        if (dateRange === 'week') {
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          return orderDate >= weekAgo;
        }
        if (dateRange === 'month') {
          return orderDate.getMonth() === now.getMonth() && orderDate.getFullYear() === now.getFullYear();
        }
        return true;
      });
    }

    // Sort by newest
    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [orders, searchQuery, activeFilter, dateRange]);

  const handleUpdatePaymentStatus = (orderId: string, status: 'paid' | 'refunded' | 'confirmed' | 'failed') => {
    const statusText = status === 'confirmed' ? 'Confirmed' : status === 'paid' ? 'Paid' : status === 'failed' ? 'Failed' : 'Refunded';
    if (confirm(`Are you sure you want to mark this order as ${statusText}?`)) {
      const updatedOrders = orders.map(o => 
        o.id === orderId ? { ...o, paymentStatus: status } : o
      );
      storage.saveOrders(updatedOrders);
      setOrders(updatedOrders);
    }
  };

  const handleExport = () => {
    const csvContent = [
      ['Order ID', 'Date', 'Customer', 'Email', 'Amount', 'Payment Method', 'Payment Status', 'Payment ID'],
      ...filteredOrders.map(o => [
        o.id,
        new Date(o.createdAt).toLocaleDateString(),
        o.userName,
        o.userEmail,
        o.totalAmount,
        o.paymentMethod?.toUpperCase() || 'N/A',
        o.paymentStatus?.toUpperCase() || 'N/A',
        o.paymentId || 'N/A'
      ])
    ].map(e => e.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `luxardo_finance_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8">
      {/* Debug Info */}
      <div className="hidden">Dashboard Loaded: Accounts</div>
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-black mb-2 tracking-tight">Finance Overview</h1>
          <p className="text-gray-500 font-medium">Manage payments, refunds, and financial records.</p>
        </div>
        <button 
          onClick={handleExport}
          className="px-6 py-3 bg-black text-white font-bold text-xs uppercase tracking-widest rounded-xl hover:bg-gray-900 transition-all flex items-center gap-2 shadow-lg shadow-black/10 w-fit"
        >
          <Download size={16} /> Export Data
        </button>
      </div>

      {/* Top Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {[
          { label: 'Total Revenue', value: formatCurrency(stats.totalRevenue), icon: DollarSign },
          { label: 'Confirmed', value: stats.confirmedPayments, icon: CheckCircle2 },
          { label: 'Pending Payments', value: stats.pendingPayments, icon: Clock },
          { label: 'Refunded Orders', value: stats.refundedOrders, icon: RotateCcw },
          { label: 'COD Orders', value: stats.codOrders, icon: Banknote },
          { label: 'Prepaid Orders', value: stats.prepaidOrders, icon: CreditCard },
        ].map((stat, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="p-3 rounded-xl w-fit mb-4 bg-gray-50 text-black">
              <stat.icon size={20} />
            </div>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-black truncate">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Main Content Area */}
      <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden flex flex-col">
        {/* Toolbar */}
        <div className="p-4 border-b border-gray-100 flex flex-col lg:flex-row gap-4 justify-between items-center bg-gray-50/50">
          {/* Search */}
          <div className="relative w-full lg:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text"
              placeholder="Search by ID, name, email, phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-black transition-all"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
            <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-1">
              {(['all', 'confirmed', 'pending', 'refunded', 'cod', 'prepaid'] as FilterType[]).map((f) => (
                <button
                  key={f}
                  onClick={() => setActiveFilter(f)}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${
                    activeFilter === f ? 'bg-black text-white' : 'text-gray-500 hover:text-black hover:bg-gray-50'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
            
            <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-1">
              {(['all', 'today', 'week', 'month'] as DateRangeType[]).map((d) => (
                <button
                  key={d}
                  onClick={() => setDateRange(d)}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${
                    dateRange === d ? 'bg-gray-200 text-black' : 'text-gray-500 hover:text-black hover:bg-gray-50'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white border-b border-gray-100">
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest whitespace-nowrap">Order Details</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest whitespace-nowrap">Customer</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest whitespace-nowrap">Amount</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest whitespace-nowrap">Payment</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest whitespace-nowrap text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredOrders.length > 0 ? (
                filteredOrders.map(o => (
                  <tr key={o.id} className={`hover:bg-gray-50/50 transition-colors group ${
                    o.paymentStatus !== 'confirmed' && o.paymentStatus !== 'paid' ? 'border-l-4 border-l-red-500' : 
                    o.verificationStatus === 'dispatch_ready' || o.status === 'shipped' || o.status === 'delivered' ? 'border-l-4 border-l-emerald-500' : 'border-l-4 border-l-amber-500'
                  }`}>
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-black mb-1">#{o.id}</div>
                      <div className="text-xs text-gray-500">{new Date(o.createdAt).toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-black mb-1">{o.userName}</div>
                      <div className="text-xs text-gray-500">{o.userEmail}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-black">{formatCurrency(o.totalAmount)}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-2 items-start">
                        <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded bg-gray-100 text-gray-600">
                          {o.paymentMethod || 'N/A'}
                        </span>
                        {o.paymentStatus === 'paid' && (
                          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-emerald-600">
                            <CheckCircle2 size={12} /> Paid
                          </span>
                        )}
                        {o.paymentStatus === 'confirmed' && (
                          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-blue-600">
                            <CheckCircle2 size={12} /> Confirmed
                          </span>
                        )}
                        {o.paymentStatus === 'pending' && (
                          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-amber-600">
                            <Clock size={12} /> Pending
                          </span>
                        )}
                        {o.paymentStatus === 'refunded' && (
                          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-red-600">
                            <RotateCcw size={12} /> Refunded
                          </span>
                        )}
                        {o.paymentStatus === 'failed' && (
                          <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-red-600">
                            <XCircle size={12} /> Failed
                          </span>
                        )}
                        {o.paymentId && (
                          <span className="text-[9px] text-gray-400 font-mono mt-1">
                            ID: {o.paymentId}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Link 
                          to={`/accounts/orders/${o.id}`}
                          className="p-2 text-gray-400 hover:text-black hover:bg-white rounded-lg border border-transparent hover:border-gray-200 transition-all"
                          title="View Order"
                        >
                          <Eye size={16} />
                        </Link>
                        {o.paymentStatus !== 'confirmed' && o.paymentStatus !== 'paid' && o.paymentStatus !== 'refunded' && o.paymentStatus !== 'failed' && (
                          <>
                            <button 
                              onClick={() => handleUpdatePaymentStatus(o.id, 'confirmed')}
                              className="p-2 text-gray-400 hover:text-blue-600 hover:bg-white rounded-lg border border-transparent hover:border-gray-200 transition-all"
                              title="Confirm Payment"
                            >
                              <CheckSquare size={16} />
                            </button>
                            <button 
                              onClick={() => handleUpdatePaymentStatus(o.id, 'failed')}
                              className="p-2 text-gray-400 hover:text-red-600 hover:bg-white rounded-lg border border-transparent hover:border-gray-200 transition-all"
                              title="Reject Payment"
                            >
                              <XCircle size={16} />
                            </button>
                          </>
                        )}
                        {o.paymentStatus === 'confirmed' && (
                          <button 
                            onClick={() => handleUpdatePaymentStatus(o.id, 'paid')}
                            className="p-2 text-gray-400 hover:text-emerald-600 hover:bg-white rounded-lg border border-transparent hover:border-gray-200 transition-all"
                            title="Mark as Paid"
                          >
                            <CheckCircle2 size={16} />
                          </button>
                        )}
                        {o.paymentStatus === 'paid' && (
                          <button 
                            onClick={() => handleUpdatePaymentStatus(o.id, 'refunded')}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-white rounded-lg border border-transparent hover:border-gray-200 transition-all"
                            title="Mark as Refunded"
                          >
                            <RotateCcw size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-400 text-sm">
                    No financial records found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
