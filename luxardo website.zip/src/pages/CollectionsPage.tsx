import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { COLLECTIONS } from '../constants';
import { Search, X } from 'lucide-react';
import { storage } from '../utils/localStorage';
import { ProductCard } from '../components/ProductCard';
import { useAuth } from '../context/AuthContext';

export default function CollectionsPage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'newest' | 'recommended'>('featured');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  const collections = COLLECTIONS.map(col => ({
    id: col.id,
    title: col.fullName,
    path: `/collections/${col.id}`,
    img: col.image,
    descriptor: col.descriptor
  }));

  const allProducts = storage.getProducts();

  const filteredProducts = useMemo(() => {
    let result = [...allProducts];

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query)
      );
    }

    // Filter by category
    if (selectedCategory) {
      result = result.filter(p => p.category === selectedCategory);
    }

    // Prime member restrictions
    if (!user?.isPrimeMember) {
      result = result.filter(p => p.readyToStitch);
    }

    // Sorting
    if (sortBy === 'newest') {
      result = [...result].reverse();
    } else if (sortBy === 'recommended') {
      result = [...result].sort((a, b) => a.id.localeCompare(b.id));
    }

    return result;
  }, [allProducts, searchQuery, sortBy, user, selectedCategory]);

  const categories = useMemo(() => {
    const cats = Array.from(new Set(allProducts.map(p => p.category)));
    return cats;
  }, [allProducts]);

  return (
    <div className="min-h-screen bg-brand-bg pb-32">
      {/* Editorial Hero Section */}
      <div className="pt-24 pb-12 md:pt-32 md:pb-16 px-4 md:px-12 max-w-[1800px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="space-y-2 md:space-y-4"
        >
          <span className="text-[9px] md:text-[10px] uppercase tracking-[0.3em] md:tracking-[0.4em] font-bold text-brand-secondary">
            The Archive
          </span>
          <h1 className="text-4xl md:text-7xl lg:text-8xl font-display tracking-tight text-brand-black">
            COLLECTIONS
          </h1>
        </motion.div>
      </div>

      {/* Sticky Controls Bar */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-200 py-4 px-4 md:px-8">
        <div className="flex justify-between items-center text-[11px] font-sans uppercase tracking-widest text-black">
          {/* Left: Filter Toggle */}
          <button 
            onClick={() => setSelectedCategory(selectedCategory ? null : categories[0])} // Simple toggle for now, can be expanded
            className="flex items-center gap-2 hover:opacity-70 transition-opacity"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="4" x2="20" y1="21" y2="21" />
              <line x1="4" x2="20" y1="14" y2="14" />
              <line x1="4" x2="20" y1="7" y2="7" />
            </svg>
            <span>Filter and Sort</span>
          </button>

          {/* Right: Sort & Count */}
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2 cursor-pointer hover:opacity-70">
              <span>Price, High to Low</span>
              <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <span className="hidden md:inline">{filteredProducts.length} Products</span>
          </div>
        </div>
      </div>

      <div className="w-full bg-white">
        {/* Main Product Grid */}
        <AnimatePresence mode="wait">
          <motion.div 
            key={selectedCategory || 'all'}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-0">
                {filteredProducts.map((product, idx) => (
                  <div key={product.id} className="border-r border-b border-transparent hover:border-gray-100 transition-colors">
                    <ProductCard product={product} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-48 text-center bg-white">
                <p className="text-xl font-sans uppercase tracking-widest text-gray-500 mb-8">
                  No pieces found.
                </p>
                <button 
                  className="text-[11px] uppercase tracking-widest border-b border-black pb-1" 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory(null);
                  }}
                >
                  Reset Filters
                </button>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
